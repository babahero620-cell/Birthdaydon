# Premium Interactive Birthday Surprise

## Run
```bash
npm install
npm run dev
```

## Customize
Edit only `src/config/birthdayConfig.js` for normal personalization. Put your own photos in `public/images/` and music in `public/audio/birthday.mp3`.

Missing photos and music fail gracefully, so the experience remains usable.
